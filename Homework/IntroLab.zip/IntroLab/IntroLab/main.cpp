/*
 * File:   main.cpp
 * Author: Catherine Wallin
 * Created on August 27, 2020, 12:09 PM
 * Purpose: Intro Lab
 */

//System Libraries
#include <iostream> //I/O Library
using namespace std;

//User Libraries

//Global Constants Only

//Function Prototypes

//Execution of Code Begins Here
int main(int argc, char** argv) {
    //set the random number seed here
    
    //Declare all variables for this function
    
    //Initialize all known variables
    
    //Process Inputs to Outputs -> mapping process
    //Maps known values to the unknown objects
    
    //Display Inputs/Outputs 
    cout << "Hello World!" << endl;
    
    //Clean up the code, close files, deallocate memory, etc...
    //Exit
    return 0;
}
 //Function Implementation