var searchData=
[
  ['finalplayerstats_133',['FinalPlayerStats',['../class_final_player_stats.html#a476f1268fc33dff89b82bc942f8241bc',1,'FinalPlayerStats::FinalPlayerStats()'],['../class_final_player_stats.html#a7ea6a831d39eedb21663de25596b9c43',1,'FinalPlayerStats::FinalPlayerStats(const Player &amp;player)']]]
];
