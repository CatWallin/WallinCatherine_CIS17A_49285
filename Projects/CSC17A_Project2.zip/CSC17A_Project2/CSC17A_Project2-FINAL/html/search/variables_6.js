var searchData=
[
  ['salary_205',['salary',['../class_player.html#a954f93f6b901b2853694b33a40ff8a1d',1,'Player']]]
];
