var searchData=
[
  ['career_192',['career',['../class_player.html#a93f3862061a4bbf138f2f3218a0bf4b0',1,'Player']]],
  ['children_193',['children',['../class_player.html#a407ee780e69fc48ab3d17274c38b09f8',1,'Player']]],
  ['currentboardposition_194',['currentBoardPosition',['../class_player.html#ad78a7c30d22a5f30f139121a5c16c0b7',1,'Player']]]
];
