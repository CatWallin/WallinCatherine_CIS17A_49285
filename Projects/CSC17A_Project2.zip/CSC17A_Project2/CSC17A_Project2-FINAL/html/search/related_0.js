var searchData=
[
  ['gamestats_221',['GameStats',['../class_final_player_stats.html#abe7c3aa4e16a095f9fd2ce0baf7f5ff2',1,'FinalPlayerStats']]]
];
