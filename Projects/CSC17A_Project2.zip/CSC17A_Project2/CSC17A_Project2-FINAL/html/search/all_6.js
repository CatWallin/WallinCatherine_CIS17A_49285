var searchData=
[
  ['initiatespin_46',['initiateSpin',['../class_spin.html#a5990675966048e94b06944d699c8b8bf',1,'Spin']]],
  ['invalidsalary_47',['InvalidSalary',['../class_player_1_1_invalid_salary.html',1,'Player']]]
];
