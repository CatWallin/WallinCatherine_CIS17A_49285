var searchData=
[
  ['invalidsalary_110',['InvalidSalary',['../class_player_1_1_invalid_salary.html',1,'Player']]]
];
