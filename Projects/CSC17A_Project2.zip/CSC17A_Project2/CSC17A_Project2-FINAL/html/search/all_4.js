var searchData=
[
  ['finalplayerstats_15',['FinalPlayerStats',['../class_final_player_stats.html',1,'FinalPlayerStats'],['../class_final_player_stats.html#a476f1268fc33dff89b82bc942f8241bc',1,'FinalPlayerStats::FinalPlayerStats()'],['../class_final_player_stats.html#a7ea6a831d39eedb21663de25596b9c43',1,'FinalPlayerStats::FinalPlayerStats(const Player &amp;player)']]],
  ['finalplayerstats_2ecpp_16',['FinalPlayerStats.cpp',['../_final_player_stats_8cpp.html',1,'']]],
  ['finalplayerstats_2eh_17',['FinalPlayerStats.h',['../_final_player_stats_8h.html',1,'']]]
];
