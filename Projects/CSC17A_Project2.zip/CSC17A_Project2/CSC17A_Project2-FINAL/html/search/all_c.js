var searchData=
[
  ['operator_2b_2b_64',['operator++',['../class_player.html#a5b6e4cf8da8ae2a019a032e5388a0456',1,'Player']]],
  ['operator_2b_3d_65',['operator+=',['../class_player.html#a30e970552fa2d45097ff2bc25ef50a49',1,'Player']]],
  ['operator_2d_2d_66',['operator--',['../class_final_player_stats.html#afc7a6b7830b8fa669ff323db76054342',1,'FinalPlayerStats']]]
];
