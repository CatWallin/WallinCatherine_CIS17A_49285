var searchData=
[
  ['degree_195',['degree',['../class_player.html#a5c2c984ed6c70a53650dfaa464f426dc',1,'Player']]],
  ['degreerequired_196',['degreeRequired',['../class_job_base.html#a14304bb94e31b72e75e0da33670c0504',1,'JobBase']]]
];
