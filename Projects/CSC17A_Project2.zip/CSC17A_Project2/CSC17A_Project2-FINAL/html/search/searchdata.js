var indexSectionsWithContent =
{
  0: "bcdefgijklmnopstu~",
  1: "cfgijps",
  2: "cdfgjmps",
  3: "cdfgijlmopst~",
  4: "cdelmpstu",
  5: "b",
  6: "gklnpt",
  7: "g"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Friends"
};

