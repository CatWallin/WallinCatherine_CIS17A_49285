var searchData=
[
  ['spin_2eh_126',['Spin.h',['../_spin_8h.html',1,'']]]
];
