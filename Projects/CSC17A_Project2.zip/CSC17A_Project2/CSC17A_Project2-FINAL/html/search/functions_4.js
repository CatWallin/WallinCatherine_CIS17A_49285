var searchData=
[
  ['initiatespin_158',['initiateSpin',['../class_spin.html#a5990675966048e94b06944d699c8b8bf',1,'Spin']]]
];
