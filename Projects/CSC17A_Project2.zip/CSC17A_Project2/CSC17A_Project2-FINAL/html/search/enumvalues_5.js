var searchData=
[
  ['taxesdue_218',['TaxesDue',['../main_8cpp.html#ae3c884a2649e84aa460276e216f127a1a10f1b2118317cf94075803e7d0bab610',1,'main.cpp']]],
  ['taxrefund_219',['TaxRefund',['../main_8cpp.html#ae3c884a2649e84aa460276e216f127a1a47cb495b6658c1ce73fc099dfd4cbb45',1,'main.cpp']]],
  ['tradesalary_220',['TradeSalary',['../main_8cpp.html#ae3c884a2649e84aa460276e216f127a1aed2bf6bf53b138b061f050353634abd4',1,'main.cpp']]]
];
